"use strict";

const quiz = document.querySelector("#assessment");
const questions = JSON.parse(document.querySelector("#questions").textContent);
const selections = Array(questions.length).fill(null);
let current = 0;

function make(tag, text, className) {
  const element = document.createElement(tag);
  element.textContent = text;
  if (className) element.className = className;
  return element;
}

function button(text, className = "button") {
  const element = make("button", text, className);
  element.type = "button";
  return element;
}

function showQuestion(moveFocus = true) {
  const question = questions[current];
  const progress = make("p", `Question ${current + 1} of ${questions.length}`, "eyebrow");
  const form = document.createElement("form");
  const fieldset = document.createElement("fieldset");
  const legend = make("legend", question.prompt);
  legend.tabIndex = -1;
  fieldset.append(legend);

  const next = button(current === questions.length - 1 ? "Submit assessment" : "Next");
  next.type = "submit";
  next.disabled = selections[current] === null;
  question.options.forEach((option, index) => {
    const label = make("label", "", "choice");
    const input = document.createElement("input");
    input.type = "radio";
    input.name = "answer";
    input.checked = selections[current] === index;
    input.addEventListener("change", () => {
      selections[current] = index;
      next.disabled = false;
    });
    label.append(input, make("span", option.text));
    fieldset.append(label);
  });

  const controls = make("div", "", "actions");
  if (current > 0) {
    const back = button("Previous", "button secondary");
    back.addEventListener("click", () => {
      current -= 1;
      showQuestion();
    });
    controls.append(back);
  }
  controls.append(next);
  form.append(fieldset, controls);
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (selections[current] === null) return;
    current += 1;
    if (current === questions.length) showScore();
    else showQuestion();
  });
  quiz.replaceChildren(progress, form);
  if (moveFocus) legend.focus();
}

function showScore() {
  const score = questions.filter((question, index) => question.options[selections[index]].correct).length;
  const passed = score >= 4;
  const heading = make("h2", passed ? "Assessment passed" : "Assessment complete");
  heading.tabIndex = -1;
  const summary = make("p", `You scored ${score} out of ${questions.length}. A score of 4 or higher passes.`);
  const controls = make("div", "", "actions");
  const retry = button("Retry assessment", passed ? "button secondary" : "button");
  retry.addEventListener("click", () => {
    selections.fill(null);
    current = 0;
    showQuestion();
  });
  controls.append(retry);
  if (passed) {
    const next = make("a", quiz.dataset.nextLabel, "button");
    next.href = quiz.dataset.next;
    controls.append(next);
  }
  quiz.replaceChildren(heading, summary, controls);
  heading.focus();
}

showQuestion(false);
