# HopeHealth Home Care · Leading Through Communication

A six-module e-learning portfolio by Mhilu A. Kiluwasha, KiluWorks Enterprise, LLC. The public edition contains the H5P lessons and practice activities, a Handoff Challenge, and a five-question browser-scored assessment for each module. A score of 4/5 passes. The public edition accepts unlimited assessment retries.

## Publish on GitHub Pages

1. Extract this ZIP.
2. Put the extracted files and folders at the root of the repository's `main` branch, including `.nojekyll`.
3. In **Settings → Pages**, set the source to **Deploy from a branch**. Select **main** and **/(root)**, then save.
4. Use the URL shown in **Settings → Pages** as your portfolio link.

## Preview locally

From the extracted directory, run `python3 -m http.server 8000`, then open `http://localhost:8000`. A web server is recommended for the H5P runtime.

Moodle handles the staff course, account access, records, progression rules, and certificates. The public assessments calculate scores for the current visit. As with other client-side quizzes, the assessment content and scoring logic are present in the published site files.
